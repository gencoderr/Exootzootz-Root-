
import React, { useState, useCallback } from 'react';
import { generateExplanation } from './services/geminiService';
import type { ExplanationResponse } from './types';
import CodeViewer from './components/CodeViewer';
import ExplanationPanel from './components/ExplanationPanel';
import { GO_CODE_EXAMPLE } from './constants';
import { GoIcon } from './components/icons/GoIcon';

const App: React.FC = () => {
  const [explanation, setExplanation] = useState<ExplanationResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hoveredLine, setHoveredLine] = useState<number | null>(null);

  const handleGenerateExplanation = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setExplanation(null);
    try {
      const result = await generateExplanation(GO_CODE_EXAMPLE);
      setExplanation(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <main className="w-full max-w-7xl mx-auto animate-fade-in">
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-2">
            <GoIcon className="h-12 w-12 text-cyan-400" />
            <h1 className="text-4xl font-bold tracking-tight text-white sm:text-5xl">
              Go Path Tokenizer AI Explainer
            </h1>
          </div>
          <p className="mt-2 text-lg leading-8 text-gray-400">
            An AI-powered tool to dissect and understand Go code for path manipulation.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-gray-800/50 p-6 rounded-lg shadow-2xl border border-gray-700/50">
            <h2 className="text-2xl font-semibold mb-4 text-cyan-300">Go Source Code</h2>
            <CodeViewer 
              code={GO_CODE_EXAMPLE} 
              onLineHover={setHoveredLine}
              highlightedLine={hoveredLine}
            />
          </div>
          <div className="bg-gray-800/50 p-6 rounded-lg shadow-2xl border border-gray-700/50 flex flex-col">
            <h2 className="text-2xl font-semibold mb-4 text-cyan-300">AI Analysis</h2>
            <ExplanationPanel
              isLoading={isLoading}
              error={error}
              explanation={explanation}
              onGenerate={handleGenerateExplanation}
              onLineHover={setHoveredLine}
              highlightedLine={hoveredLine}
            />
          </div>
        </div>
      </main>
      <footer className="w-full max-w-7xl mx-auto text-center py-6 mt-8 text-gray-500 text-sm">
        <p>Powered by Google Gemini. Built with React & Tailwind CSS.</p>
      </footer>
    </div>
  );
};

export default App;
