
import React from 'react';

export const GoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 128 128"
    fill="none"
    {...props}
  >
    <path
      fill="currentColor"
      d="M63.89 128a63.89 63.89 0 100-127.78A63.89 63.89 0 0063.89 128z"
    ></path>
    <path
      fill="#fff"
      d="M39.11 72.89v-9.56c0-9.33 3.44-14.78 12.33-14.78 5.78 0 9.22 1.67 12.33 5.22l-6 6.33c-1.89-2.33-3.67-3.22-6.33-3.22-3.11 0-4.44 2.11-4.44 5.78v10.22h17.11v8.89H39.11v11H60v-8.89H48v-2.11zM72.22 84v-9.11c0-4.78 1.44-7 4.56-7 3 0 4.44 2.22 4.44 7v9.11h8.89V67.33h-8.89v9c-2.33-2.78-4.44-4.22-8.33-4.22-6.67 0-10.44 4.56-10.44 11.22V84h8.77z"
    ></path>
  </svg>
);
