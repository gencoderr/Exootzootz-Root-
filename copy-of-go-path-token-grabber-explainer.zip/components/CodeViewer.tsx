
import React from 'react';

interface CodeViewerProps {
  code: string;
  onLineHover: (lineNumber: number | null) => void;
  highlightedLine: number | null;
}

const CodeViewer: React.FC<CodeViewerProps> = ({ code, onLineHover, highlightedLine }) => {
  const lines = code.split('\n');

  return (
    <div className="bg-gray-900 rounded-md overflow-hidden font-mono text-sm">
      <div className="flex">
        <div className="line-numbers text-right pr-4 text-gray-500 select-none flex-shrink-0">
          {lines.map((_, index) => (
            <div 
              key={index}
              className={`h-6 leading-6 ${highlightedLine === index + 1 ? 'text-cyan-400' : ''}`}
            >
              {index + 1}
            </div>
          ))}
        </div>
        <pre className="flex-grow">
          <code className="language-go">
            {lines.map((line, index) => (
              <div
                key={index}
                onMouseEnter={() => onLineHover(index + 1)}
                onMouseLeave={() => onLineHover(null)}
                className={`h-6 leading-6 transition-colors duration-200 px-2 rounded-r-md ${
                  highlightedLine === index + 1 ? 'bg-cyan-900/50' : ''
                }`}
              >
                {line}
              </div>
            ))}
          </code>
        </pre>
      </div>
    </div>
  );
};

export default CodeViewer;
