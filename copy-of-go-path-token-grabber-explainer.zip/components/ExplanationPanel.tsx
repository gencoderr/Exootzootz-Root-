
import React from 'react';
import type { ExplanationResponse } from '../types';
import PathVisualizer from './PathVisualizer';
import { BrainIcon } from './icons/BrainIcon';

interface ExplanationPanelProps {
  isLoading: boolean;
  error: string | null;
  explanation: ExplanationResponse | null;
  onGenerate: () => void;
  onLineHover: (lineNumber: number | null) => void;
  highlightedLine: number | null;
}

const LoadingSpinner: React.FC = () => (
  <div className="flex flex-col items-center justify-center h-full text-center">
    <svg className="animate-spin -ml-1 mr-3 h-8 w-8 text-cyan-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
    </svg>
    <p className="mt-4 text-lg text-gray-400">AI is analyzing the code...</p>
    <p className="text-sm text-gray-500">This may take a moment.</p>
  </div>
);

const InitialState: React.FC<{ onGenerate: () => void }> = ({ onGenerate }) => (
  <div className="flex flex-col items-center justify-center h-full text-center p-4">
    <BrainIcon className="h-16 w-16 text-gray-600 mb-4" />
    <h3 className="text-xl font-semibold text-white">Ready for Analysis</h3>
    <p className="mt-2 max-w-sm text-gray-400">
      Click the button below to have Gemini analyze the Go code and provide a detailed, line-by-line explanation.
    </p>
    <button
      onClick={onGenerate}
      className="mt-6 inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background bg-cyan-600 text-white hover:bg-cyan-500 h-10 py-2 px-4"
    >
      Generate Explanation
    </button>
  </div>
);

const ExplanationPanel: React.FC<ExplanationPanelProps> = ({ 
  isLoading, error, explanation, onGenerate, onLineHover, highlightedLine 
}) => {
  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center text-red-400">
        <h3 className="text-xl font-semibold">An Error Occurred</h3>
        <p className="mt-2">{error}</p>
        <button
          onClick={onGenerate}
          className="mt-6 inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors bg-red-600 text-white hover:bg-red-500 h-10 py-2 px-4"
        >
          Try Again
        </button>
      </div>
    );
  }

  if (!explanation) {
    return <InitialState onGenerate={onGenerate} />;
  }

  return (
    <div className="space-y-6 animate-slide-in-up">
      <div>
        <h3 className="text-lg font-semibold text-gray-300 mb-2">Overall Purpose</h3>
        <p className="text-gray-400">{explanation.overallExplanation}</p>
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-300 mb-2">Path Visualization</h3>
        <PathVisualizer path={explanation.path} tokens={explanation.tokens} />
      </div>

      <div>
        <h3 className="text-lg font-semibold text-gray-300 mb-2">Line-by-Line Breakdown</h3>
        <ul className="space-y-3">
          {explanation.lineByLine.map(({ line, explanation: text }) => (
            <li
              key={line}
              onMouseEnter={() => onLineHover(line)}
              onMouseLeave={() => onLineHover(null)}
              className={`p-3 rounded-md transition-colors duration-200 ${
                highlightedLine === line ? 'bg-cyan-900/50' : 'bg-gray-800'
              }`}
            >
              <span className="font-mono text-cyan-400 mr-3 text-xs p-1 bg-gray-900 rounded">
                L{line}
              </span>
              <span className="text-gray-400">{text}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default ExplanationPanel;
