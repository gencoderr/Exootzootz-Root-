
import React from 'react';

interface PathVisualizerProps {
  path: string;
  tokens: string[];
}

const PathVisualizer: React.FC<PathVisualizerProps> = ({ path, tokens }) => {
  return (
    <div className="bg-gray-900 p-4 rounded-lg">
      <div className="mb-4">
        <p className="text-xs text-gray-500 uppercase font-semibold">Original Path</p>
        <p className="font-mono text-green-400 break-all">{path}</p>
      </div>
      <div>
        <p className="text-xs text-gray-500 uppercase font-semibold">Tokens</p>
        <div className="flex flex-wrap gap-2 mt-2">
          {tokens.map((token, index) => {
             // Handle root directory case for Unix-like systems
            const displayToken = token === "" && index === 0 ? "/" : token;
            return (
              <div
                key={index}
                className="bg-gray-700 text-gray-300 font-mono text-sm px-3 py-1 rounded-md animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {displayToken}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default PathVisualizer;
