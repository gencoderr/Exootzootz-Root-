
import { GoogleGenAI, Type } from "@google/genai";
import type { ExplanationResponse } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    overallExplanation: {
      type: Type.STRING,
      description: "A high-level summary of what the Go code does.",
    },
    path: {
      type: Type.STRING,
      description: "The specific file path string being processed in the code.",
    },
    tokens: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "An array of strings representing the path components (tokens).",
    },
    lineByLine: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          line: { type: Type.INTEGER },
          explanation: { type: Type.STRING },
        },
        required: ["line", "explanation"],
      },
      description: "A detailed, line-by-line explanation of the code.",
    },
  },
  required: ["overallExplanation", "path", "tokens", "lineByLine"],
};

export async function generateExplanation(code: string): Promise<ExplanationResponse> {
  const prompt = `
    Analyze the following Go code. Your task is to explain what it does, identify the file path it processes, list the tokens it extracts from that path, and provide a line-by-line breakdown.

    Go Code:
    \`\`\`go
    ${code}
    \`\`\`

    Provide the analysis in a JSON format matching the defined schema.
    For the line-by-line explanation, focus on the lines inside the main function.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    const jsonText = response.text.trim();
    // In case the API wraps the JSON in markdown backticks
    const cleanedJsonText = jsonText.replace(/^```json\n?/, '').replace(/\n?```$/, '');
    const parsedResponse = JSON.parse(cleanedJsonText);
    
    // Ensure line numbers are integers
    parsedResponse.lineByLine = parsedResponse.lineByLine.map((item: { line: string | number; explanation: string; }) => ({
        ...item,
        line: parseInt(String(item.line), 10)
    }));
    
    return parsedResponse as ExplanationResponse;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to get explanation from AI. Please check the console for details.");
  }
}
