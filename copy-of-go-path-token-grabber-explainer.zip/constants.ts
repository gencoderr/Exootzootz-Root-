
export const GO_CODE_EXAMPLE = `package main

import (
	"fmt"
	"path/filepath"
	"strings"
)

func main() {
	// Define a sample file path for demonstration.
	// On Windows, it could be "C:\\Users\\Test\\file.txt"
	// On Linux/macOS, it could be "/home/user/app/data.csv"
	filePath := "/home/user/app/data.csv"

	// Use filepath.SplitList to handle OS-specific path separators.
	// This function splits the path into a slice of its components.
	tokens := strings.Split(filePath, string(filepath.Separator))

	// Print the original path.
	fmt.Printf("Original Path: %s\\n", filePath)

	// Print the extracted tokens.
	fmt.Println("Extracted Tokens:")
	for i, token := range tokens {
		if token == "" && i == 0 {
			// Handle the root directory case on Unix-like systems
			token = "/"
		}
		fmt.Printf("  [%d]: %s\\n", i, token)
	}
}
`;
