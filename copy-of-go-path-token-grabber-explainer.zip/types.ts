
export interface LineExplanation {
  line: number;
  explanation: string;
}

export interface ExplanationResponse {
  overallExplanation: string;
  path: string;
  tokens: string[];
  lineByLine: LineExplanation[];
}
