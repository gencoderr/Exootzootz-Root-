#!/bin/bash

docker build -t transfer-learning-tf ./docker
